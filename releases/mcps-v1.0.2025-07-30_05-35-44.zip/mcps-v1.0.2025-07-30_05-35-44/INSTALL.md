# MCP Servers Installation

## Quick Start

### 1. Install JoyCaption MCP
```bash
cd joycaption-mcp
pip install -e .
```

### 2. Install Domain Checker MCP  
```bash
cd domain-checker
pip install -e . 
```

### 3. Add to Claude Code Configuration
```json
{
  "mcpServers": {
    "joycaption": {
      "command": "python",
      "args": ["-m", "joycaption_mcp"],
      "cwd": "/path/to/joycaption-mcp"
    },
    "domain-checker": {
      "command": "python", 
      "args": ["-m", "domain_checker_mcp"],
      "cwd": "/path/to/domain-checker"
    }
  }
}
```
